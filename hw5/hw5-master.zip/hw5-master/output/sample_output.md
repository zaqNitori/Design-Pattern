# Sample output
```
$ mvn exec:java -Dexec.mainClass="org.ntutssl.termfrequency.Main" -Dexec.args="input/pride-and-prejudice.txt 10 des"
...
mr: 786
elizabeth: 635
very: 488
darcy: 418
such: 395
mrs: 343
much: 329
more: 327
bennet: 323
bingley: 306
...
```